// @flow
import CanCan from "cancan";
export default new CanCan();
