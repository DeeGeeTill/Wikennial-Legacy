// @flow
import BaseModel from "./BaseModel";

class NotificationSetting extends BaseModel {
  id: string;
  event: string;
}

export default NotificationSetting;
