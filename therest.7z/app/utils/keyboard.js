// @flow

export const meta = window.navigator.platform === "MacIntel" ? "⌘" : "Ctrl";
