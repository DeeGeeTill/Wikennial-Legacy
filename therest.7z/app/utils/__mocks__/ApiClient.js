/* eslint-disable */
export default {
  client: {
    post: jest.fn(() => Promise.resolve),
  },
};
