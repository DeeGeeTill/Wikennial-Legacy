// @flow
import RootStore from "stores/RootStore";

const stores = new RootStore();

export default stores;
