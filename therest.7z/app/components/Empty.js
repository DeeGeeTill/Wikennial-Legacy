// @flow
import styled from "styled-components";

const Empty = styled.p`
  color: ${(props) => props.theme.textTertiary};
`;

export default Empty;
