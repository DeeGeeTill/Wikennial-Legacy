// @flow
import ListPlaceholder from "./ListPlaceholder";
import LoadingPlaceholder from "./LoadingPlaceholder";

export default LoadingPlaceholder;
export { ListPlaceholder };
