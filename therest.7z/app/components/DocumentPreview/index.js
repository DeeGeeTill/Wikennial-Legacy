// @flow
import DocumentPreview from "./DocumentPreview";
export default DocumentPreview;
