// @flow
import DocumentHistory from "./DocumentHistory";
export default DocumentHistory;
