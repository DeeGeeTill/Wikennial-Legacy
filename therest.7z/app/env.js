// @flow
const env = window.env;
export default env;
