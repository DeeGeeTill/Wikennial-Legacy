// Mock for node-uuid
global.console.warn = () => {};
