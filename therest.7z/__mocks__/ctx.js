const ctx = {
  cache: {
    set: () => {},
  },
};

export default ctx;
