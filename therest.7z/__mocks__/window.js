window.matchMedia = data => data;
